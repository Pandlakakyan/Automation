# Selenium_Projects


I have written scripts to automate various manual actions which we perform in the browsers using selenium webdriver.
